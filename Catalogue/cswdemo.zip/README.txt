Files from SDI training on 28.09.2011x
